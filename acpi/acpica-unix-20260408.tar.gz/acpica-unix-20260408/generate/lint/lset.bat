set path=%PATH%;$G
